/* ===== UI REFERENCES ===== */
const ui = {

    // ===== ACTION BUTTONS =====
    fightBtn: document.getElementById('fightBtn'),
    magicBtn: document.getElementById('magicBtn'),
    itemBtn: document.getElementById('itemBtn'),
    summonBtn: document.getElementById('summonBtn'),
    actBtn: document.getElementById('actBtn'),

    // ===== SUBMENU BUTTONS =====
    basicAtkBtn: document.getElementById('basicAtkBtn'),

    // ===== MENUS =====
    fightMenu: document.getElementById('fightMenu'),
    magicMenu: document.getElementById('magicMenu'),
    itemMenu: document.getElementById('itemMenu'),
    summonMenu: document.getElementById('summonMenu'),
    actMenu: document.getElementById('actMenu'),

    // ===== ENEMY DISPLAY =====
    enemyNameTxt: document.getElementById('enemyNameTxt'),
    enemyHealthTxt: document.getElementById('enemyHealthTxt'),

    // ===== PLAYER DISPLAY =====
    playerHealthTxt: document.getElementById('playerHealthTxt'),
    playerManaTxt: document.getElementById('playerManaTxt'),
    playerStatusTxt: document.getElementById('playerStatusTxt'),

    // ===== LOG BOX =====
    logMain: document.getElementById('logMain'),
    logEnemy: document.getElementById('logEnemy'),
    logMisc: document.getElementById('logMisc'),

};


/* ===== ENEMY DEFINITIONS ===== */
const enemies = {
    gremlin: {
        health: 2000,
        maxHealth: 2000,
        friendliness: 3,
        agression: 1,
        loyalty: 0
    }
};


/* ===== PLAYER OBJECT ===== */
const player = {
	attack(damage) {
		currentEnemy.health -= damage;
	}
};


/* ===== CURRENT ENEMY ===== */
let currentEnemy = enemies.gremlin;

/* ===== PLAYER VARIABLES ===== */
let playerHealth = 500;
let playerMana = 0;



/* ========================== */
/* V ===== GAME LOGIC =====  V*/
/* ========================== */




/* ===== BUTTON MENU SWITCHING ===== */
ui.fightBtn.addEventListener("click", function () {
    switchManager();
    ui.fightMenu.style.display = "flex";
});

ui.magicBtn.addEventListener("click", function(){
    switchManager();
    ui.magicMenu.style.display = "flex";
});

ui.itemBtn.addEventListener("click", function(){
    switchManager();
    ui.itemMenu.style.display = "flex";
});

ui.summonBtn.addEventListener("click", function(){
    switchManager();
    ui.summonMenu.style.display = "flex";
});

ui.actBtn.addEventListener("click", function(){
    switchManager();
    ui.actMenu.style.display = "flex";
});


/* V ===== ATTACK LOGIC ===== V */

/* ===== BASIC ATTACK LOGIC ===== */
ui.basicAtkBtn.addEventListener("click", function(){
    let playerDamage = getRandom(8, 12);
    player.attack(playerDamage);
    cooldown(200, ui.basicAtkBtn);
    shake();
    BGFlash("red");
    updateDisplays();
});

/* ================================= */
/* V ===== UTILITY FUNCTIONS =====  V*/
/* ================================= */


/* ===== RANDOM NUMBER ===== */
function getRandom(min, max) {
	return Math.floor(Math.random() * (max - min + 1)) + min;
};


/* ===== SUBMENU SWITCHER ===== */
function switchManager() {
    ui.fightMenu.style.display = "none";
    ui.magicMenu.style.display = "none";
    ui.itemMenu.style.display = "none";
    ui.summonMenu.style.display = "none";
    ui.actMenu.style.display = "none";
};


/* ===== SCREEN SHAKE ===== */
function shake() {
    const e = document.documentElement;
    e.classList.remove("shake");
    void e.offsetWidth;
    e.classList.add("shake");
    setTimeout(() => e.classList.remove("shake"), 500);
};


/* ===== FLASH EFFECTS ===== */
function BGFlash(color) {
    document.body.classList.remove(
        'bg-flash-red',
        'bg-flash-blue',
        'bg-flash-yellow'
    );
    void document.body.offsetWidth;
    document.body.classList.add(`bg-flash-${color}`);
};


/* ===== COOLDOWN FUNCTION ===== */
function cooldown(time, element) {
    element.style.backgroundColor = "gray";
    element.disabled = true;
    element.style.cursor = "not-allowed";

    setTimeout(function(){
        element.style.backgroundColor = "";
        element.disabled = false;
        element.style.cursor = "pointer";
    }, time)
};


/* ===== UI DISPLAY UPDATER ===== */
function updateDisplays() {
    ui.enemyHealthTxt.textContent = `Health: ${currentEnemy.health} / ${currentEnemy.maxHealth}`;
};


/* ===== I HAVE NO CLUE ===== */
function smurfShuffle() {
    console.log("help help help help help help help help help help help help help help help help help help help help help help help help help help ");
};

updateDisplays();

// todo:
// make it so act uses the friendliness whatever stats to see if the thingy does a cool thing and helps u or sum idk
// there should be like 8 enemies
// im so bored and proud of my code at the same time imma show this to my friends

// when you say you're fine but you're not really fine
// also for devs reading my horrible code, just remember you probably used to code like this too at one point
// ok u can leave now
// really
// ...
// whatever i'll just make this be the last comment >:3